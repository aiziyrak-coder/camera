function e(e,t){let n=URL.createObjectURL(e),r=document.createElement(`a`);r.href=n,r.download=t,document.body.appendChild(r),r.click(),r.remove(),setTimeout(()=>URL.revokeObjectURL(n),0)}function t(t,n,r){let i=[t,...n].map(e=>e.map(e=>`"${String(e).replace(/"/g,`""`)}"`).join(`;`)).join(`\r
`);e(new Blob([`﻿sep=;\r
`+i],{type:`text/csv;charset=utf-8`}),r)}export{t};